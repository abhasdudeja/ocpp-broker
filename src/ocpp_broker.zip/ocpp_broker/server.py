"""
server.py
---------
Entry point for running the OCPP Broker server.

This file launches the FastAPI application that acts as the middleware broker
between EV chargers (OCPP clients) and backend systems.

Compatible with:
✅ Windows
✅ Linux / macOS
✅ Python 3.10+
"""

import asyncio
import argparse
import signal
import sys
import logging
import uvicorn
import yaml
from pathlib import Path

from fastapi import FastAPI

# Local imports
from ocpp_broker.backend_manager import BackendManager
from ocpp_broker.broker import OcppBroker
from ocpp_broker.config import BrokerConfig


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

logger = logging.getLogger("ocpp_broker.server")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


# ---------------------------------------------------------------------------
# FastAPI initialization
# ---------------------------------------------------------------------------

app = FastAPI(title="OCPP Broker", version="0.2.0")

backend_manager: BackendManager | None = None
broker: OcppBroker | None = None


@app.get("/health")
async def health_check():
    """Simple health check endpoint."""
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Configuration loading
# ---------------------------------------------------------------------------

def load_config(config_path: str | None) -> BrokerConfig:
    """Load broker configuration from YAML file."""
    default_path = Path(__file__).parent.parent / "config.yaml"
    path = Path(config_path) if config_path else default_path

    if not path.exists():
        logger.error(f"Configuration file not found: {path}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        config_data = yaml.safe_load(f)

    config = BrokerConfig(**config_data)
    logger.info(f"Loaded configuration from {path}")
    return config


# ---------------------------------------------------------------------------
# Async server logic
# ---------------------------------------------------------------------------

async def start_broker(config: BrokerConfig):
    """Initialize and start broker asynchronously."""
    global backend_manager, broker

    backend_manager = BackendManager(config)
    broker = OcppBroker(config, backend_manager)

    logger.info("Starting OCPP Broker WebSocket server...")
    await broker.start()


def run_broker_server(config_path: str | None):
    """Main run function — compatible with Windows and Unix systems."""
    config = load_config(config_path)

    # Start FastAPI (HTTP/REST) and OCPP broker (WebSocket)
    async def main_async():
        await start_broker(config)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    # ✅ Safe signal handling
    if sys.platform != "win32":
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, loop.stop)
    else:
        # Windows fallback: stop on Ctrl+C
        def handle_keyboard_interrupt():
            try:
                loop.run_forever()
            except KeyboardInterrupt:
                logger.info("Keyboard interrupt received, stopping broker...")
                loop.stop()

        import threading
        threading.Thread(target=handle_keyboard_interrupt, daemon=True).start()

    # Run the broker and FastAPI concurrently
    async def serve():
        broker_task = asyncio.create_task(main_async())

        uvicorn_config = uvicorn.Config(
            app,
            host=config.http_host,
            port=config.http_port,
            log_level="info",
        )
        uvicorn_server = uvicorn.Server(uvicorn_config)

        fastapi_task = asyncio.create_task(uvicorn_server.serve())

        await asyncio.wait(
            [broker_task, fastapi_task],
            return_when=asyncio.FIRST_EXCEPTION,
        )

    try:
        loop.run_until_complete(serve())
    except KeyboardInterrupt:
        logger.info("Shutting down broker and FastAPI server...")
    finally:
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()
        logger.info("OCPP Broker stopped cleanly.")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Run the OCPP Broker server.")
    parser.add_argument(
        "-c", "--config",
        help="Path to configuration YAML file (default: ./config.yaml)",
        default=None,
    )
    args = parser.parse_args()

    run_broker_server(args.config)


if __name__ == "__main__":
    main()
